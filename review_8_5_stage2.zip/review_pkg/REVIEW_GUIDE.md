# 复核指南 —— §8.5 第二阶段（联合 7 维搜索）

## 包内容
- 代码（与 GitHub `lyl-715/SYS-ID` 分支 `claude/optimistic-newton-xv5jvl` 的 `code_8_3_stage2/stage2_pkg/` 一致）：
  - `mc83.py`（公共设置、`sod`、`cfun`，已过审，未改）、`mc84.py`（MLE / Hotelling / Wishart）、
    `mc85_scan.py`、`mc85_post.py`、`mc85_lhs.py`（第一阶段与 LHS 候选的生成与评价）
  - `stage2_common.py`（numba 触发 `sod_batch` + 按位一致性检查、`evaluate_crn`）
  - `stage2_post.py` → `stage2_refine.py` → `stage2_local.py` → `stage2_final.py` → `stage2_figs.py` → `stage2_followup.py`
  - `mc85_stage2_protocol.md`：协议与跑前预测
- 输入数据：`mc85_scan_part0..4.json`、`mc85_amp20.json`、`mc85_lhs_part*.json`（R=200，种子 20261010）、`wk_d20_10000.npy`
- 输出（`stage2/`）：`stage2_report.md`（Claude Code 的报告）、六个 `*.log`、中间与最终 JSON/NPZ、三张图
- `section_8_5_stage2_CN.md`：我据 `stage2_report.md` 写的中文稿，请对照核转述是否走样

## 复现
在包的根目录（需 numpy、scipy、matplotlib、numba）：

    python3 stage2_post.py && python3 stage2_refine.py && python3 stage2_local.py && python3 stage2_final.py && python3 stage2_figs.py && python3 stage2_followup.py

约 8 分钟（4 进程）。种子固定（见 `stage2_report.md` §0 表），应与 `stage2/*.log` 逐数一致。

## 数的追溯
`stage2_report.md` 每张表注明来源表号与日志文件；`section_8_5_stage2_CN.md` 的每个数取自 `stage2_report.md`。
请按 日志 → 英文报告 → 中文稿 三层核。

## 建议重点核的地方
1. `stage2_common.py::sod_batch` 与 `mc83.sod` 的按位一致性（日志行 `trigger check ... 100/100 trajectories (31827 events)`）；可独立重跑该检查。
2. `stage2_local.py`：罚项目标 f = −Δm_D + 1·max(0, D+2se) + 20·max(0, λ0−m_E)；新候选是否先在 R=2000（种子 20261012）重算再进入排名；是否存在不同 R 的估计值混排。
3. `stage2_final.py`：批 2（种子 20261014）的 CRLB 是否取自批 1（20261013）的 J；`stage2_followup.py` 的批 3（20261015）、批 4（20261016）是否与前面独立；批 4 内两候选共用抽样这一限定是否如实写出。
4. 窗内输入功率表（`stage2_followup.log` Table F3）：长期功率 Σa_m²/2 = 0.5 对所有候选成立；P_in(UNIF)=0.7051 为长期功率的 1.41 倍；高 D 候选 0.36–0.43。
5. 预测核对（报告 §5）是否与 `mc85_stage2_protocol.md` 中跑前写下的四条逐条对应，有无事后改写。
6. 中文稿 8.5.9 的三条"待定"是否超出报告支持的范围。

## 已知的协议外选择（报告 §7 已列）
细化选点规则 F1/F2/FL/BB；罚权 1 nat/次与 20 nat/单位 m_E；单纯形步长 0.25；前沿分区阈值 0.1/0.3；反例阈值（≥10 次、≥0.3 nat）；最终 7 个候选的选取规则；m_E 的批 se 定义。
